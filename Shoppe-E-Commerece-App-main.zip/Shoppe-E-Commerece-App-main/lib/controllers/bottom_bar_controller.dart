import 'package:get/get.dart';

class BottomBarController extends GetxController {
  RxInt pageIndex = 4.obs;
}
