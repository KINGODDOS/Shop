import 'package:get/get.dart';

class FavouritePageController extends GetxController {
  RxInt selectedIndex = 0.obs;
}
