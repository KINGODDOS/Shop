import 'package:get/get.dart';

class HomePageController extends GetxController {
  RxInt selectedDiscountIndex = 2.obs;
  List discounts = ['All', "10%", "20%", "30%", "40%", "50%"];
}
