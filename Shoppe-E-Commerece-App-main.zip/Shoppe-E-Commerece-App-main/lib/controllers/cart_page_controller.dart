import 'package:get/get.dart';
import 'package:shoppe_e_commerece_app/models/cart_items_model.dart';

class CartPageController extends GetxController {
  RxList cartItems = [
    CartItems(
        imagePath: 'assets/images/i5.png',
        price: 2800,
        detail: 'Lorem ipsum dolor sit amet consectetur.',
        color: 'Pink',
        items: 1),
    CartItems(
        imagePath: 'assets/images/i6.png',
        price: 3100,
        detail: 'Lorem ipsum dolor sit amet consectetur.',
        color: 'Red',
        items: 1),
    CartItems(
        imagePath: 'assets/images/i7.png',
        price: 2750,
        detail: 'Lorem ipsum dolor sit amet consectetur.',
        color: 'Cream',
        items: 1),
    CartItems(
        imagePath: 'assets/images/i8.png',
        price: 2800,
        detail: 'Lorem ipsum dolor sit amet consectetur.',
        color: 'Yellow',
        items: 1),
  ].obs;

  RxDouble totalPrice = 0.0.obs;

  void calculateTotalPrice() {
    double sum = 0.0;
    for (var item in cartItems) {
      sum += item.price * item.items;
    }
    totalPrice.value = sum;
  }

  void addItem(int index) {
    cartItems[index].items++;
    calculateTotalPrice();
    cartItems.refresh();
  }

  void removeItem(int index) {
    cartItems[index].items <= 1
        ? cartItems[index].items = 1
        : cartItems[index].items--;
    calculateTotalPrice();
    cartItems.refresh();
  }

  void removeItemFromCart(int index) {
    cartItems.removeAt(index);
    calculateTotalPrice();
  }

  @override
  void onInit() {
    super.onInit();
    calculateTotalPrice();
  }
}
