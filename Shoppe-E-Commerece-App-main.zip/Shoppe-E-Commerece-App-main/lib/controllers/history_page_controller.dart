import 'package:get/get.dart';
import 'package:shoppe_e_commerece_app/models/ordered_item.dart';

class HistoryPageController extends GetxController {
  var orderedItems = <OrderedItem>[
    OrderedItem(
        image: 'assets/images/i6.png',
        orderNumber: 'Order #92287157',
        price: 100,
        items: 1),
    OrderedItem(
        image: 'assets/images/i5.png',
        orderNumber: 'Order #92287179',
        price: 120,
        items: 2),
    OrderedItem(
        image: 'assets/images/i2.png',
        orderNumber: 'Order #92287251',
        price: 75,
        items: 1),
    OrderedItem(
        image: 'assets/images/s4.png',
        orderNumber: 'Order #92283232',
        price: 95,
        items: 3),
    OrderedItem(
        image: 'assets/images/i12.png',
        orderNumber: 'Order #92283240',
        price: 140,
        items: 2),
    OrderedItem(
        image: 'assets/images/i9.png',
        orderNumber: 'Order #92287157',
        price: 85,
        items: 1),
    OrderedItem(
        image: 'assets/images/i1.png',
        orderNumber: 'Order #92287251',
        price: 75,
        items: 1),
    OrderedItem(
        image: 'assets/images/s2.png',
        orderNumber: 'Order #92283232',
        price: 95,
        items: 3),
  ].obs;
}
