import 'package:get/get.dart';
import 'package:shoppe_e_commerece_app/models/new_items.dart';
import 'package:shoppe_e_commerece_app/models/recently_viewed.dart';

class ProfilePageController extends GetxController {
  List recentlyViewImagePath = [
    RecentlyViewed(imagePath: 'assets/images/1.png'),
    RecentlyViewed(imagePath: 'assets/images/2.png'),
    RecentlyViewed(imagePath: 'assets/images/3.png'),
    RecentlyViewed(imagePath: 'assets/images/4.png'),
    RecentlyViewed(imagePath: 'assets/images/5.png'),
  ];

  List storiesImage = [
    'assets/images/s1.png',
    'assets/images/s2.png',
    'assets/images/s3.png',
    'assets/images/s4.png',
  ];

  List newItemsList = [
    NewItems(imagePath: 'assets/images/i1.png', price: 1700),
    NewItems(imagePath: 'assets/images/i2.png', price: 3400),
    NewItems(imagePath: 'assets/images/i3.png', price: 2800),
    NewItems(imagePath: 'assets/images/i4.png', price: 1900),
    NewItems(imagePath: 'assets/images/s1.png', price: 1700),
    NewItems(imagePath: 'assets/images/s2.png', price: 3400),
    NewItems(imagePath: 'assets/images/s3.png', price: 2800),
    NewItems(imagePath: 'assets/images/s4.png', price: 1900),
    NewItems(imagePath: 'assets/images/i5.png', price: 2800),
    NewItems(imagePath: 'assets/images/i6.png', price: 2800),
    NewItems(imagePath: 'assets/images/i7.png', price: 2800),
    NewItems(imagePath: 'assets/images/i8.png', price: 2800),
    NewItems(imagePath: 'assets/images/i9.png', price: 2800),
    NewItems(imagePath: 'assets/images/i10.png', price: 2800),
    NewItems(imagePath: 'assets/images/i11.png', price: 2800),
  ];
}
