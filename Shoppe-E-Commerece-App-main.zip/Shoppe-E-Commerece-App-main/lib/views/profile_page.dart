import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:shoppe_e_commerece_app/common/app_strings.dart';
import 'package:shoppe_e_commerece_app/controllers/profile_page_controller.dart';
import 'package:shoppe_e_commerece_app/widgets/item_container.dart';

class ProfilePage extends StatelessWidget {
  ProfilePage({super.key});

  ProfilePageController controller = Get.put(ProfilePageController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 5.h,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
              child: Row(
                children: [
                  _circleAvatar(24, 'assets/images/avatar 1.png'),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.blue,
                          borderRadius: BorderRadius.circular(40)),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 8, horizontal: 15),
                        child: Center(
                            child: Text(
                          AppStrings.myActivity,
                          style: TextStyle(color: Colors.white),
                        )),
                      ),
                    ),
                  ),
                  Expanded(child: SizedBox()),
                  _circleIcon(Icons.qr_code_scanner),
                  _circleIcon(Icons.align_horizontal_left),
                  _circleIcon(Icons.settings),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20),
              child: Container(
                alignment: Alignment.centerLeft,
                child: Text(
                  AppStrings.hello,
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppStrings.announcement,
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w700),
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(top: 2, right: 30),
                              child: Text(
                                AppStrings.LoremIpsum,
                                style: TextStyle(fontSize: 10),
                                textAlign: TextAlign.justify,
                                softWrap: true,
                              ),
                            ),
                          ),
                          Container(
                            child: CircleAvatar(
                                radius: 15,
                                backgroundColor: Colors.blue,
                                child: Icon(
                                  Icons.arrow_forward_outlined,
                                  color: Colors.white,
                                  size: 20,
                                )),
                          )
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            _headingText(AppStrings.recentlyView),
            GridView.builder(
              shrinkWrap: true,
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              itemCount: controller.recentlyViewImagePath.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 5, mainAxisSpacing: 10, crossAxisSpacing: 10),
              itemBuilder: (context, index) {
                return _circleAvatar(
                        28, controller.recentlyViewImagePath[index].imagePath)
                    .fadeInRight(delay: Duration(milliseconds: index * 200));
              },
            ),
            _headingText(AppStrings.myOrders),
            Container(
              height: 7.h,
              child: ListView.separated(
                shrinkWrap: true,
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                itemCount: 3,
                separatorBuilder: (context, index) => SizedBox(
                  width: 1.h,
                ),
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, index) {
                  return _myOrderContainers(index == 0
                      ? 'To Pay'
                      : index == 1
                          ? "To Recieve"
                          : 'To Review');
                },
              ),
            ),
            SizedBox(
              height: 10,
            ),
            _headingText(AppStrings.stories),
            Container(
              height: 20.5.h,
              child: ListView.separated(
                shrinkWrap: true,
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                itemCount: 4,
                separatorBuilder: (context, index) => SizedBox(
                  width: 10,
                ),
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, index) {
                  return Stack(
                    children: [
                      Container(
                        width: 100,
                        height: double.infinity,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            color: Colors.black,
                            image: DecorationImage(
                                image:
                                    AssetImage(controller.storiesImage[index]),
                                fit: BoxFit.cover)),
                      ),
                      Positioned(
                          left: 0,
                          right: 0,
                          top: 0,
                          bottom: 0,
                          child: Image.asset(
                            'assets/images/play.png',
                            scale: 4,
                          )),
                      index == 0
                          ? Positioned(
                              top: 5,
                              left: 5,
                              child: Image.asset(
                                'assets/images/live.png',
                                scale: 4,
                              ))
                          : SizedBox(),
                    ],
                  ).fadeInRight(delay: Duration(milliseconds: index * 200));
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10, right: 20, bottom: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _headingText(AppStrings.newItems),
                  Row(
                    children: [
                      Text(
                        AppStrings.seeAll,
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w700),
                      ),
                      SizedBox(
                        width: 15,
                      ),
                      CircleAvatar(
                        radius: 15,
                        backgroundColor: Colors.blue,
                        child: Icon(
                          Icons.arrow_forward,
                          color: Colors.white,
                          size: 22,
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
            Container(
              height: 240,
              child: ListView.separated(
                padding: EdgeInsets.symmetric(horizontal: 20),
                itemCount: 4,
                scrollDirection: Axis.horizontal,
                physics: BouncingScrollPhysics(),
                shrinkWrap: true,
                separatorBuilder: (context, index) => SizedBox(
                  width: 10,
                ),
                itemBuilder: (context, index) {
                  return ItemContainer(
                    imagePath: controller.newItemsList[index].imagePath,
                    price: controller.newItemsList[index].price,
                  ).fadeInRight(delay: Duration(milliseconds: index * 200));
                },
              ),
            )
          ],
        ),
      ),
    ).fadeInLeft();
  }

  Widget _myOrderContainers(text) {
    return Container(
      decoration: BoxDecoration(
          color: Color(0xFFE5EBFC), borderRadius: BorderRadius.circular(30)),
      child: Center(
          child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Text(
          text,
          style: TextStyle(
              color: Colors.blue, fontWeight: FontWeight.w500, fontSize: 16),
        ),
      )),
    );
  }

  Widget _circleAvatar(double radius, String imagePath) {
    return CircleAvatar(
      backgroundColor: Colors.white,
      radius: radius + 4,
      child: CircleAvatar(
        radius: radius,
        backgroundImage: AssetImage(imagePath),
      ),
    );
  }

  Widget _circleIcon(icon) {
    return Flexible(
      child: Padding(
        padding: const EdgeInsets.all(4.0),
        child: CircleAvatar(
          radius: 20,
          backgroundColor: Color(0xFFE5EBFC),
          child: Icon(
            icon,
            size: 18,
            color: Colors.blue,
          ),
        ),
      ),
    );
  }

  Widget _headingText(text) {
    return Padding(
      padding: const EdgeInsets.only(left: 20),
      child: Container(
        alignment: Alignment.centerLeft,
        child: Text(
          text,
          style: TextStyle(fontSize: 21, fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}
