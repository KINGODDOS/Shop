import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart'; // Make sure you're using this
import 'package:shoppe_e_commerece_app/controllers/cart_page_controller.dart';

class CartPage extends StatelessWidget {
  CartPage({super.key});

  final CartPageController controller = Get.put(CartPageController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 2.h),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      _headingText('Cart'),
                      SizedBox(width: 2.w),
                      CircleAvatar(
                        radius: 15,
                        backgroundColor: Color(0xFFE5EBFC),
                        child: Text('${controller.cartItems.length}'),
                      )
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5.w),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: EdgeInsets.all(3.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Shipping Address',
                            style: TextStyle(
                                fontSize: 15.sp, fontWeight: FontWeight.w700),
                          ),
                          SizedBox(height: 1.h),
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  '26, Duong So 2, Thao Dien Ward, An Phu, District 2, Ho Chi Minh city',
                                  style: TextStyle(fontSize: 12.sp),
                                  textAlign: TextAlign.justify,
                                  softWrap: true,
                                ),
                              ),
                              SizedBox(width: 2.w),
                              CircleAvatar(
                                radius: 15,
                                backgroundColor: Colors.blue,
                                child: Icon(Icons.edit,
                                    size: 16.sp, color: Colors.white),
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 2.h),
                Obx(
                  () => Expanded(
                    child: ListView.separated(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      separatorBuilder: (context, index) =>
                          SizedBox(height: 2.h),
                      itemCount: controller.cartItems.length,
                      itemBuilder: (context, index) {
                        return _cartItems(index);
                      },
                    ),
                  ),
                ),
              ],
            ),
            Positioned(
              bottom: 0,
              right: 0,
              left: 0,
              child: Padding(
                padding: EdgeInsets.only(
                  left: 4.w,
                  right: 4.w,
                  bottom: 3.w,
                ),
                child: Container(
                  color: Colors.grey.shade100,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text(
                            'Total ',
                            style: TextStyle(
                                fontSize: 18.sp, fontWeight: FontWeight.w800),
                          ),
                          Obx(
                            () => Text(
                              "\$${controller.totalPrice.value.toStringAsFixed(0)}",
                              style: TextStyle(
                                  fontSize: 17.sp, fontWeight: FontWeight.w700),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Container(
                          width: 35.w,
                          height: 5.h,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Colors.blue),
                          child: Center(
                            child: Text(
                              'Checkout',
                              style: TextStyle(
                                  fontSize: 16.sp, color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _headingText(text) {
    return Text(
      text,
      style: TextStyle(fontSize: 22.sp, fontWeight: FontWeight.w700),
    );
  }

  Widget _cartItems(int index) {
    return Container(
      width: double.infinity,
      height: 14.h,
      child: Row(
        children: [
          Stack(
            children: [
              Container(
                height: 14.h,
                width: 30.w,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.white, width: 4),
                  borderRadius: BorderRadius.circular(10),
                  image: DecorationImage(
                    image: AssetImage(controller.cartItems[index].imagePath),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Positioned(
                left: 1.w,
                bottom: 1.w,
                child: InkWell(
                  onTap: () => controller.removeItemFromCart(index),
                  child: Image.asset(
                    'assets/images/Frame.png',
                    scale: 4,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 0.5.h),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    controller.cartItems[index].detail,
                    style: TextStyle(fontSize: 13.sp),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 2,
                  ),
                  Text(
                    "${controller.cartItems[index].color}, Size M",
                    style: TextStyle(fontWeight: FontWeight.w500),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '\$ ${controller.cartItems[index].price}',
                        style: TextStyle(
                            fontSize: 17.sp, fontWeight: FontWeight.w700),
                      ),
                      Row(
                        children: [
                          _counterBtn(Icons.remove, () {
                            controller.removeItem(index);
                          }),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 1.w),
                            child: Container(
                              width: 8.w,
                              height: 4.h,
                              decoration: BoxDecoration(
                                color: Color(0xFFE5EBFC),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Center(
                                child: Text(
                                  controller.cartItems[index].items.toString(),
                                  style: TextStyle(fontSize: 15.sp),
                                ),
                              ),
                            ),
                          ),
                          _counterBtn(Icons.add, () {
                            controller.addItem(index);
                          }),
                        ],
                      )
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ).fadeInLeft(delay: Duration(milliseconds: index * 200));
  }

  Widget _counterBtn(IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: 8.w,
        height: 4.h,
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white,
            border: Border.all(color: Colors.blue, width: 2)),
        child: Icon(
          icon,
          color: Colors.blue,
          size: 18.sp,
        ),
      ),
    );
  }
}
