import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shoppe_e_commerece_app/controllers/home_page_controller.dart';
import 'package:shoppe_e_commerece_app/controllers/profile_page_controller.dart';
import 'package:shoppe_e_commerece_app/widgets/discount_container.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});
  HomePageController controller = Get.put(HomePageController());
  ProfilePageController profilePageController =
      Get.put(ProfilePageController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Positioned(
                right: 0,
                top: 0,
                child: Image.asset('assets/images/Bubbles.png')),
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 20, right: 20, top: 50),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        children: [
                          Text(
                            'Flash Sale',
                            style: TextStyle(
                                fontSize: 28, fontWeight: FontWeight.w700),
                          ),
                          Text(
                            'Choose Your Discount',
                            style: TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w500),
                          )
                        ],
                      ),
                      Row(
                        children: [
                          Icon(
                            Icons.watch_later_outlined,
                            color: Colors.white,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          _timeContainer(00),
                          _timeContainer(36),
                          _timeContainer(58),
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Container(
                    height: 50,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.grey.shade200),
                    child: ListView.builder(
                      itemCount: controller.discounts.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index) {
                        return Obx(
                          () => InkWell(
                            onTap: () {
                              controller.selectedDiscountIndex.value = index;
                            },
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 17),
                              child: Center(
                                child: Text(
                                  textAlign: TextAlign.center,
                                  controller.discounts[index],
                                  style: TextStyle(
                                      fontSize: controller.selectedDiscountIndex
                                                  .value ==
                                              index
                                          ? 16
                                          : 13,
                                      fontWeight: FontWeight.w700,
                                      color: controller.selectedDiscountIndex
                                                  .value ==
                                              index
                                          ? Colors.blue
                                          : Colors.black),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _headingText("20% Discount"),
                      Icon(Icons.apps_outlined)
                    ],
                  ),
                ),
                GridView.builder(
                  physics: BouncingScrollPhysics(),
                  padding: EdgeInsets.all(12),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 0,
                    childAspectRatio: 0.6,
                  ),
                  shrinkWrap: true,
                  itemCount: profilePageController.newItemsList.length,
                  itemBuilder: (context, index) {
                    return DiscountContainer(
                      imagePath:
                          profilePageController.newItemsList[index].imagePath,
                      price: profilePageController.newItemsList[index].price,
                    ).fadeInUp(delay: Duration(milliseconds: index * 200));
                  },
                )
              ],
            ),
          ],
        ),
      ),
    ).fadeInDown();
  }

  Widget _timeContainer(int time) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 1),
      child: Container(
        width: 30,
        height: 27,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Center(
          child: Text(
            "$time",
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
          ),
        ),
      ),
    );
  }

  Widget _headingText(text) {
    return Padding(
      padding: const EdgeInsets.only(left: 20),
      child: Container(
        alignment: Alignment.centerLeft,
        child: Text(
          text,
          style: TextStyle(fontSize: 21, fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}
