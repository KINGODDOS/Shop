import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shoppe_e_commerece_app/controllers/bottom_bar_controller.dart';
import 'package:shoppe_e_commerece_app/views/cart_page.dart';
import 'package:shoppe_e_commerece_app/views/favourite_page.dart';
import 'package:shoppe_e_commerece_app/views/home_page.dart';
import 'package:shoppe_e_commerece_app/views/history_page.dart';
import 'package:shoppe_e_commerece_app/views/profile_page.dart';

class BottomBar extends StatelessWidget {
  BottomBar({super.key});

  BottomBarController controller = Get.put(BottomBarController());

  List pages = [
    HomePage(),
    FavouritePage(),
    HistoryPage(),
    CartPage(),
    ProfilePage()
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              offset: Offset(0, -4),
              blurRadius: 0,
              spreadRadius: -2,
            ),
          ],
        ),
        child: Obx(
          () => BottomNavigationBar(
              onTap: (value) {
                controller.pageIndex.value = value;
              },
              backgroundColor: Colors.white,
              elevation: 2,
              showUnselectedLabels: false,
              showSelectedLabels: false,
              type: BottomNavigationBarType.fixed,
              selectedItemColor: Colors.black,
              unselectedItemColor: Colors.blue,
              currentIndex: controller.pageIndex.value,
              items: [
                BottomNavigationBarItem(
                    icon: Icon(Icons.home_outlined), label: 'Home'),
                BottomNavigationBarItem(
                    icon: Icon(Icons.favorite_outline), label: 'Favourite'),
                BottomNavigationBarItem(
                    icon: Icon(Icons.document_scanner_outlined),
                    label: 'Documents'),
                BottomNavigationBarItem(
                    icon: Icon(Icons.card_travel), label: 'Cart'),
                BottomNavigationBarItem(
                    icon: Icon(Icons.person_2_outlined), label: 'Profile'),
              ]),
        ),
      ),
      body: Obx(
        () => pages[controller.pageIndex.value],
      ),
    );
  }
}
