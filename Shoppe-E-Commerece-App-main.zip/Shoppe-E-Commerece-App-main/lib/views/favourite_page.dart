import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shoppe_e_commerece_app/controllers/favourite_page_controller.dart';
import 'package:shoppe_e_commerece_app/controllers/profile_page_controller.dart';
import 'package:shoppe_e_commerece_app/widgets/discount_container.dart';

class FavouritePage extends StatelessWidget {
  FavouritePage({super.key});
  FavouritePageController controller = Get.put(FavouritePageController());
  ProfilePageController profilePageController =
      Get.put(ProfilePageController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: SingleChildScrollView(
        child: Column(
          children: [
            _headingText('Recently viewed'),
            Container(
              height: 100,
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Obx(
                  () => Row(
                    children: [
                      Expanded(
                        child: Stack(
                          children: [
                            InkWell(
                              onTap: () {
                                controller.selectedIndex.value = 0;
                              },
                              child: Container(
                                height: 30,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(30),
                                    color: controller.selectedIndex.value == 0
                                        ? Colors.blue.shade100
                                        : Colors.grey.shade300),
                                child: Center(
                                  child: Text(
                                    'Today',
                                    style: TextStyle(
                                        fontSize: 15,
                                        fontWeight:
                                            controller.selectedIndex.value == 0
                                                ? FontWeight.w700
                                                : FontWeight.w500,
                                        color:
                                            controller.selectedIndex.value == 0
                                                ? Colors.blue
                                                : Colors.black),
                                  ),
                                ),
                              ),
                            ),
                            controller.selectedIndex.value == 0
                                ? Positioned(
                                    right: 5,
                                    top: 2,
                                    child: Image.asset(
                                      'assets/images/Check.png',
                                      scale: 2,
                                    ))
                                : SizedBox(),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: Stack(
                          children: [
                            InkWell(
                              onTap: () {
                                controller.selectedIndex.value = 1;
                              },
                              child: Container(
                                height: 30,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(30),
                                    color: controller.selectedIndex.value == 1
                                        ? Colors.blue.shade100
                                        : Colors.grey.shade300),
                                child: Center(
                                  child: Text(
                                    'Yesterday',
                                    style: TextStyle(
                                        fontSize: 15,
                                        fontWeight:
                                            controller.selectedIndex.value == 1
                                                ? FontWeight.w700
                                                : FontWeight.w500,
                                        color:
                                            controller.selectedIndex.value == 1
                                                ? Colors.blue
                                                : Colors.black),
                                  ),
                                ),
                              ),
                            ),
                            controller.selectedIndex.value == 1
                                ? Positioned(
                                    right: 5,
                                    top: 2,
                                    child: Image.asset(
                                      'assets/images/Check.png',
                                      scale: 2,
                                    ))
                                : SizedBox(),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Image.asset(
                        'assets/images/checkLarge.png',
                        scale: 2,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Obx(
              () => GridView.builder(
                physics: BouncingScrollPhysics(),
                padding: EdgeInsets.all(12),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 0.63,
                ),
                shrinkWrap: true,
                itemCount: controller.selectedIndex.value == 0
                    ? profilePageController.newItemsList.length - 7
                    : profilePageController.newItemsList.length,
                itemBuilder: (context, index) {
                  return DiscountContainer(
                    isDiscount: false,
                    imagePath: profilePageController
                        .newItemsList[controller.selectedIndex.value == 0
                            ? index + 3
                            : index]
                        .imagePath,
                    price: profilePageController
                        .newItemsList[controller.selectedIndex.value == 0
                            ? index + 3
                            : index]
                        .price,
                  ).fadeInUp(delay: Duration(milliseconds: index * 200));
                },
              ),
            )
          ],
        ),
      ),
    ).fadeInDown();
  }

  Widget _headingText(text) {
    return Padding(
      padding: const EdgeInsets.only(left: 20, top: 30),
      child: Container(
        alignment: Alignment.centerLeft,
        child: Text(
          text,
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}
