class AppStrings {
  static String myActivity = 'My Activity';
  static String hello = 'Hello, Romina!';
  static String  announcement= 'Announcement';
  static String LoremIpsum = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas hendrerit luctus libero ac vulputate.';
  static String LoremIpsumShort = 'Lorem ipsum dolor sit amet consectetur.';
  static String recentlyView = 'Recently viewed';
  static String myOrders = "My Orders";
  static String stories = "Stories";
  static String newItems = 'New Items';
  static String seeAll = 'see All';
  static String h = '';
}
