class NewItems {
  String imagePath;
  double price;
  NewItems({required this.imagePath, required this.price});
}
