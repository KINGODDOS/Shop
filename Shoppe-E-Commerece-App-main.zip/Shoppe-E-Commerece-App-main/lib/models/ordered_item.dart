class OrderedItem {
  final String image;
  final String orderNumber;
  final double price;
  final int items;

  OrderedItem({
    required this.image,
    required this.orderNumber,
    required this.price,
    required this.items,
  });
}
