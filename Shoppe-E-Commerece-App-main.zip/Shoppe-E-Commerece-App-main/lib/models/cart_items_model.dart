
class CartItems {
  String imagePath;
  String detail;
  String color;
  double price;
  int quantity;
  int items;
  String date;
  String orderNumber;
  CartItems(
      {required this.imagePath,
      required this.price,
      required this.detail,
      this.date = 'April,06',
      this.orderNumber = 'Order #92287157',
      this.quantity = 1,
      required this.items,
      required this.color});
}
