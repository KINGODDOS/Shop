class RecentlyViewed {
  String imagePath;
  RecentlyViewed({required this.imagePath});
}
