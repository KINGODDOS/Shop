import 'package:flutter/material.dart';
import 'package:shoppe_e_commerece_app/common/app_strings.dart';

class DiscountContainer extends StatelessWidget {
  String imagePath;
  double price;
  bool isDiscount;
  DiscountContainer(
      {super.key,
      required this.imagePath,
      required this.price,
      this.isDiscount = true});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Column(
        children: [
          Stack(
            children: [
              Container(
                height: 185,
                decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(width: 4, color: Colors.white),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        offset: Offset(0, 3),
                        blurRadius: 4,
                      ),
                    ],
                    image: DecorationImage(
                        image: AssetImage(imagePath), fit: BoxFit.cover)),
              ),
              isDiscount
                  ? Positioned(
                      right: 5,
                      top: 5,
                      child: Image.asset(
                        'assets/images/discount.png',
                        scale: 2,
                      ))
                  : SizedBox(),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(top: 5),
            child: Text(
              AppStrings.LoremIpsumShort,
              style: TextStyle(fontSize: 12),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Row(
              children: [
                Container(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    textAlign: TextAlign.left,
                    "\$${price.toString()}",
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                  ),
                ),
                SizedBox(
                  width: 8,
                ),
                isDiscount
                    ? Container(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          textAlign: TextAlign.left,
                          "\$${(price * 80 / 100).toString()}",
                          style: TextStyle(
                              decoration: TextDecoration.lineThrough,
                              color: Colors.red),
                        ),
                      )
                    : SizedBox(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
