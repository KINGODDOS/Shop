import 'package:flutter/material.dart';
import 'package:shoppe_e_commerece_app/common/app_strings.dart';

class ItemContainer extends StatelessWidget {
  String imagePath;
  double price;

  ItemContainer({super.key, required this.imagePath, required this.price});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 140,
      height: 210,
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Column(
        children: [
          Container(
            height: 145,
            decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(width: 4, color: Colors.white),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    offset: Offset(0, 3),
                    blurRadius: 4,
                  ),
                ],
                image: DecorationImage(
                    image: AssetImage(imagePath), fit: BoxFit.cover)),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 5),
            child: Text(
              AppStrings.LoremIpsumShort,
              style: TextStyle(fontSize: 12),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 7),
            child: Container(
              alignment: Alignment.centerLeft,
              child: Text(
                textAlign: TextAlign.left,
                "\$${price.toString()}",
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
