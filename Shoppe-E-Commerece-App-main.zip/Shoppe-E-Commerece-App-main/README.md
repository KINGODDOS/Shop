# shoppe_e_commerece_app


<p align="center">
  <img src="https://github.com/user-attachments/assets/bfc4ba7d-5a41-46cd-9696-f313637c9a9d" width="30%" />
  <img src="https://github.com/user-attachments/assets/670abd13-6938-41db-9164-d993df6fe925" width="30%" />
  <img src="https://github.com/user-attachments/assets/64acdcfe-0e23-45d1-b6fc-b182f37032f7" width="30%" />
</p>
